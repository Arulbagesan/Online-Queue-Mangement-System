<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Archive extends Model
{
  protected $fillable = [
      'firebase_key', 'user_id', 'token', 'position', 'counter', 'call_status',
  ];

  /**
   * Get the user that owns the token.
   */
  public function user()
  {
      return $this->belongsTo(User::class);
  }
}
