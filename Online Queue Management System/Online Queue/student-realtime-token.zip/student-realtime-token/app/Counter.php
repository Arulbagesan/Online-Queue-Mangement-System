<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Counter extends Model
{
  protected $fillable = [
      'staff_id', 'counter_no',
  ];
}
