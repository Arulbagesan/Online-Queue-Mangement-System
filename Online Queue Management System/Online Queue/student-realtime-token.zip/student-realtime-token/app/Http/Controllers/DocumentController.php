<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Document;
use DataTables;
use File;

class DocumentController extends Controller
{
    public function index(Request $request)
    {
        $docs = Document::latest()->get();
        if ($request->ajax()) {
            return Datatables::of($docs)
                ->addIndexColumn()
                ->addColumn('action', function ($row) {

                  $btn ='<a  style="margin-right:5px;" href="document/'. $row->file_name .'" target="_blank" data-toggle="tooltip" data-original-title="Edit" class="edit btn btn-success btn-sm viewbook">View</a>';
                  $btn =$btn. '<a href="javascript:void(0)" data-toggle="tooltip"  data-id="' . $row->id . '" data-original-title="Edit" class="edit btn btn-primary btn-sm editBook">Edit</a>';
                  $btn = $btn . ' <a href="javascript:void(0)" data-toggle="tooltip"  data-id="' . $row->id . '" data-original-title="Delete" class="btn btn-danger btn-sm deleteBook">Delete</a>';

                    return $btn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('admin.document.document_all',compact('docs'));
    }

    public function edit($id){
        $book = Document::find($id);
        return response()->json($book);
    }

    public function store(Request $request){

      //handle file
      //delete the old file from the document folder if it is update
      if($request->book_id!=null){
        $x=$request->book_id;
        $docs = Document::findOrFail($x);
        @unlink('document/' . $docs->file_name);
        $docs->delete();
      }

      //handle file
      //move the file to document folder if it is create
      if ($file = $request->file('author')){
          $photo = time().'_'.$request->file('author')->getClientOriginalName();
          $photo = str_replace(' ', '_', $photo);
          $file->move('document',$photo);
         }

         //create or update function
        Document::updateOrCreate([
            'id' => $request->book_id
        ],[
            'title' => $request->name,
            'file_name' => $photo,
        ]);

        // return response
        $response = [
            'success' => true,
            'message' => 'Document saved successfully.',
        ];
        return response()->json($response, 200);
    }

    public function destroy($id){
       $docs = Document::findOrFail($id);
       @unlink('document/' . $docs->file_name);
       $docs->delete();
       // return response
       $response = [
           'success' => true,
           'message' => 'Document deleted successfully.',
       ];
       return response()->json($response, 200);
   }
}
