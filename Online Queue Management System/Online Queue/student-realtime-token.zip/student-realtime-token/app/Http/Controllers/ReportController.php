<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Archive;
use App\Report;
use PDF;

use Illuminate\Support\Facades\Storage;
class ReportController extends Controller
{
  public function index(){
    $reports = Report::orderBy('id', 'DESC')->paginate(5);
    return view('admin.report.generate_report', compact('reports'));
  }
  public function store(Request $request){
      try {
          $date_reort= date('Y-m-d');
          $time_reort= date('H:i:s');;
          $report_get = Archive::whereDate('created_at',$request->get_date)->get();
          $report_count = Archive::whereDate('created_at',$request->get_date)->count();
          $success = true;
          $message = "User deleted successfully";
          $pdf = \App::make('dompdf.wrapper');
          $output = '

                  <html>
              <head>
                  <style>
                      /** Define the margins of your page **/
                      @page {
                          margin: 100px 25px;
                      }

                      header {
                          position: fixed;
                          top: -60px;
                          left: 0px;
                          right: 0px;
                          height: 50px;

                          /** Extra personal styles **/
                          background-color: #03a9f4;
                          color: white;
                          text-align: center;
                          line-height: 35px;
                      }

                      footer {
                          position: fixed;
                          bottom: -60px;
                          left: 0px;
                          right: 0px;
                          height: 50px;

                          /** Extra personal styles **/
                          background-color: #03a9f4;
                          color: white;
                          text-align: center;
                          line-height: 35px;
                      }
                  </style>
              </head>
              <body>
                  <!-- Define header and footer blocks before your content -->
                  <header>
                      <img src="../public/images/1.png" height="50px" width="100%"><br><br><br><br><br><br>
                  </header>

                  <footer>
                      Copyright &copy;Student Queue Sdn Berhad  <?php echo date("Y");?>
                  </footer>

                  <!-- Wrap the content of your PDF inside a main tag -->
                  <main>

                       <p style="float: left">
                       <center><b>Student Queue Sdn Berhad</b><br>
                       <i>11-05 & 11-06, Tower A, <br>Ave 3 Vertical Business Suite,<br> Jalan Kerinchi, Bangsar South, 59200 Kuala Lumpur, Malaysia</i>

                       <br> <span>Date : '.$date_reort.'</span>&nbsp;&nbsp;
                        <span>Time : '.$time_reort.'</span><br>
                          </center>
                       </p>
                      <center>
                      <p>----------------------------------------------------------------------------------------------------------------------------------------</p>
                       </center>
                       <h3 align="center">Student Queue Report</h3>
                        <h4 align="right">Total Student Served : '.$report_count.'</h4>
                       <table width="100%" style="border-collapse: collapse; border: 0px;">
                        <tr>
                      <th style="border: 1px solid; padding:12px;" width="20%">Name</th>
                      <th style="border: 1px solid; padding:12px;" width="30%">Counter</th>
                      <th style="border: 1px solid; padding:12px;" width="15%">Time</th>

                     </tr>
                      ';
        foreach($report_get as $customer)
        {
          $output .= '
          <tr>
           <td style="border: 1px solid; padding:12px;">'.$customer->user->name.'</td>
           <td style="border: 1px solid; padding:12px;">'.$customer->counter.'</td>
           <td style="border: 1px solid; padding:12px;">'.$customer->created_at.'</td>
          </tr>
          ';
        }

        $output .= '

                    </main>
                </body>
            </html>
          ';
        //expoert report to folder and open it in browser
        $pdf->loadHtml($output);
        $pdf_string =   $pdf->output();
        $fileNo=$request->get_date;
        $filePath="reports/".$fileNo.time()."_file.pdf";
        $file_name=$fileNo.time()."_file.pdf";
        file_put_contents($filePath, $pdf_string );
        //return $pdf->stream($file_name);//show it in browser
        //insert file name to database
        Report::create([
            'report_name' => $file_name,
        ]);

      } catch (\Exception $e) {
          $success = false;
          $message = $e->getMessage();
      }
      // return response
      if ($success)
          return redirect()->back()->with('success', $message);
      else
          return redirect()->back()->with('error', $message);
  }
}
