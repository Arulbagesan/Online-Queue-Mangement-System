<?php

namespace App\Http\Controllers\API;

use App\Document;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Http\Request;

class DocumentController extends Controller
{
    /**
     * List
     */
    public function list(Request $request)
    {
        // all documents
        $documents = Document::orderBy('id', "DESC")->get();

        // format response
        $results = [];
        foreach ($documents as $document) {
            $items = [
                'id' => $document->id,
                'title' => $document->title,
                'filename' => $document->file_name,
                'link' => env('APP_URL') . '/document/' . $document->file_name,
                'created_at' => Carbon::parse($document->created_at)->format('d F, y h:i A'),
                'updated_at' => Carbon::parse($document->updated_at)->format('d F, y h:i A'),
            ];
            array_push($results, $items);
        }

        // return response
        $response = [
            'success' => true,
            'results' => $results,
        ];
        return response()->json($response);
    }
}
