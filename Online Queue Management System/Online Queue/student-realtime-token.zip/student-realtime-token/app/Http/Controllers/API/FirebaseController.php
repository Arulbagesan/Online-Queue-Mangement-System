<?php

namespace App\Http\Controllers\API;

use App\Counter;
use App\Http\Controllers\Controller;
use App\Token;
use App\Archive;
use App\User;
use DB;
use Illuminate\Http\Request;

class FirebaseController extends Controller
{
    private $database, $reference_queue, $reference_total_queue;

    public function __construct()
    {
        $this->database = app('firebase.database');
        $this->reference_queue = "queue";
        $this->reference_total_queue = "total_queue";
    }

    /**
     * Insert user to queue
     */
    public function appoint(Request $request)
    {
        // requests
        $user_id = $request->user_id;
        $firebase_key = $request->firebase_key;

        // generate new firebase key
//        $firebase_key = $this->database->getReference($this->reference_queue)->push()->getKey();

        // user info
        $user = User::where('id', $user_id)->first();
        $student_id = $user->student_id;
        $student_name = $user->name;

        // set counter
        $tokens = Token::all();
        $counters = Counter::all();
        $total_counter = Counter::count();
        if (!$tokens->isEmpty()) {
            $check_queue_in_counters = [];

            foreach ($counters as $counter) {
                $count_queue = Token::where('counter', $counter->counter_no)->count();
                $counter_item = [
                    'counter_no' => $counter->counter_no,
                    'in_queue' => $count_queue,
                ];
                array_push($check_queue_in_counters, $counter_item);
            }

            // check min queue counter
            $in_queues = array_column($check_queue_in_counters, 'in_queue');
            $min_queue = $check_queue_in_counters[array_search(min($in_queues), $in_queues)];
            $counter = $min_queue['counter_no'];
        } else {
            $counter = rand(1, $total_counter);
        }

        // set position
        $position = Token::where('counter', $counter)->count() + 1;

        // generate token
        $last_token = Token::orderBy('id', 'DESC')->first();
        if ($last_token != null) {
            $generated_token = $last_token->token + 1;
        } else {
            $generated_token = 001;
        }

        // format token
        $generated_token = str_pad($generated_token, 3, '0', STR_PAD_LEFT);

        // store to database
        $new_token = new Token();
        $new_token->firebase_key = $firebase_key;
        $new_token->user_id = $user_id;
        $new_token->token = $generated_token;
        $new_token->position = $position;
        $new_token->counter = $counter;
        $new_token->save();

        // store to archive database
        $new_token_ar = new Archive();
        $new_token_ar->firebase_key = $firebase_key;
        $new_token_ar->user_id = $user_id;
        $new_token_ar->token = $generated_token;
        $new_token_ar->position = $position;
        $new_token_ar->counter = $counter;
        $new_token_ar->save();

        // store data to firebase
        $queueData = [
            'position' => strval($position),
            'token' => strval($generated_token),
            'counter' => strval($counter),
            'student_id' => strval($student_id),
            'student_name' => strval($student_name),
            'call_status' => 0,
        ];
        $updates = [
            $this->reference_queue . '/' . $firebase_key => $queueData,
        ];
        $this->database->getReference()->update($updates);

        // update total queue in firebase
        $all_counters = Counter::all();
        $updateCounterData = [];
        foreach ($all_counters as $counter) {
            $counter_no = $counter->counter_no;
            $in_queue = Token::where('counter', $counter_no)->count();
            $updateCounterData['counter_' . $counter_no] = $in_queue;
        }
        $this->database->getReference($this->reference_total_queue)->set($updateCounterData);

        // return response
        $data = [
            'success' => true,
            'message' => "Please wait in queue",
            'firebase_key' => $firebase_key,
        ];
        return response()->json($data);
    }

    /**
     * Delete user from queue
     */
    public function cancelAppoint(Request $request)
    {
        // requests
        $firebase_key = $request->firebase_key;

        // save to archive

        // delete token from database
        Token::where('firebase_key', $firebase_key)->delete();

        // delete from firebase
        $this->database->getReference($this->reference_queue . '/' . $firebase_key)->remove();

        // update total queue in firebase
        $all_counters = Counter::all();
        $updateCounterData = [];
        foreach ($all_counters as $counter) {
            $counter_no = $counter->counter_no;
            $in_queue = Token::where('counter', $counter_no)->count();
            $updateCounterData['counter_' . $counter_no] = $in_queue;
        }
        $this->database->getReference($this->reference_total_queue)->set($updateCounterData);

        // return response
        $data = [
            'success' => true,
            'message' => "Successfully cancelled the appointment",
            'firebase_key' => $firebase_key,
        ];
        return response()->json($data);
    }
}
