<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    /**
     * User login
     */
    public function login(Request $request) {
        // requests
        $email = $request->email;
        $password = $request->password;

        // check login details
        if (Auth()->attempt(['email' => $email, 'password' => $password])) {
            // user info
            $user = User::where('email', $email)->first();
            $user_id = $user->id;
            $student_name = $user->name;
            $student_id = $user->student_id;

            $success = true;
            $message = "Login successful";
        }
        else {
            $user_id = "";
            $student_name = "";
            $student_id = "";

            $success = false;
            $message = "Please enter correct email/password";
        }

        // return response
        $data = [
            'success' => $success,
            'message' => $message,
            'user_id' => $user_id,
            'student_id' => $student_id,
            'student_name' => $student_name,
        ];
        return response()->json($data);
    }
}
