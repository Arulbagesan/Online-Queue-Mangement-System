<?php

namespace App\Http\Controllers;

use App\Counter;
use App\Token;
use App\User;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;

class TokenController extends Controller
{
    private $database, $reference_queue, $reference_total_queue;

    /**
     * Construct
     */
    public function __construct()
    {
        $this->database = app('firebase.database');
        $this->reference_queue = "queue";
        $this->reference_total_queue = "total_queue";
    }

    /**
     * Display queue.
     */
    public function index(Request $request)
    {
        $staff = User::find(Auth::id());
        $counter_no = $staff->counter->counter_no;

        $tokens = Token::where('counter', $counter_no)->get();
        $in_service = Token::where('counter', $counter_no)->first();
        $next = Token::where('counter', $counter_no)->skip(1)->first();
        $in_queue = Token::where('counter', $counter_no)->count();

        return view('staff.token_list', compact('counter_no', 'in_queue', 'tokens', 'in_service', 'next'));
    }

    /**
     * Call next token
     */
    public function nextToken(Request $request)
    {
        $counter_no = $request->counter_no;
        $in_service_firebase_key = $request->firebase_key;

        if ($in_service_firebase_key != null) {
            // save to archive

            // delete from database
            Token::where('firebase_key', $in_service_firebase_key)->delete();

            // delete from firebase
            $this->database->getReference($this->reference_queue . '/' . $in_service_firebase_key)->remove();

            // update total queue in firebase
            $all_counters = Counter::all();
            $updateCounterData = [];
            foreach ($all_counters as $counter) {
                $counter_no = $counter->counter_no;
                $in_queue = Token::where('counter', $counter_no)->count();
                $updateCounterData['counter_' . $counter_no] = $in_queue;
            }
            $this->database->getReference($this->reference_total_queue)->set($updateCounterData);

            // update positions in database
            Token::where('counter', $counter_no)->decrement('position');

            // update positions in firebase
            $rest_tokens = Token::where('counter', $counter_no)->get();
            foreach ($rest_tokens as $rest_token) {
                $new_position = $rest_token->position;

                $updateData = [
                    'position' => strval($new_position),
                    'token' => strval($rest_token->token),
                    'counter' => strval($rest_token->counter),
                    'student_id' => strval($rest_token->user->student_id),
                    'student_name' => strval($rest_token->user->name),
                    'call_status' => strval($rest_token->call_status),
                ];
                $updates = [
                    $this->reference_queue . '/' . $rest_token->firebase_key => $updateData,
                ];
                $this->database->getReference()->update($updates);
            }

            // redirect
            return redirect()->route('token_list');
        }
    }
}
