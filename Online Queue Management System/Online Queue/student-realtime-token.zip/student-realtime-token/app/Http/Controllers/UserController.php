<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Auth;
class UserController extends Controller
{
    /**
     * User list
     */

    public function list(Request $request) {
        $users = User::orderBy('id', 'DESC')->paginate(5);
        if ($request->ajax()) {
            return view('user.ajax_loader', compact('users'));
        }
        return view('user.list', compact('users'));
    }

    //add user
    public function add() {

        return view('user.add');
    }
    public function store(Request $request) {
            //validate user
            $validator = Validator::make($request->all(), [
            'email' => 'required|unique:users|max:255',
            'password' => 'required|confirmed',
              ]);

              if ($validator->fails()) {
                  return redirect()->back()->withInput()->with('error', 'Can Not add Users');
              }
            try {
                User::create([
                   'name' => $request->name,
                   'email' => $request->email,
                   'password' => Hash::make($request->password),
                   'role' => Hash::make($request->role),
               ]);
                $success = true;
                $message = "User deleted successfully";
            } catch (\Exception $e) {
                $success = false;
                $message = $e->getMessage();
            }
            // return response
            if ($success)
                return redirect()->route('list')->with('success', 'Added successfully');
            else
                return redirect()->back()->with('error', 'Can Not add Users');

    }

    //edit user
    public function edit($id){
       $users = User::findOrFail($id);
       return view('user.edit', compact('users'));
   }
   //update data
   public function update(Request $request){
      //validate input
      $users = User::findOrFail($request->id);
      $users->name = $request->name;
      $users->email = $request->email;
      $users->role = $request->role;
      $users->save();
      return redirect()->route('list')->with('success', 'Updated successfully');
  }

      //edit user
      public function edit_profile(){
         $users = User::findOrFail(Auth::id());
         return view('user.edit_profile', compact('users'));
     }

     public function update_profile(Request $request){
       //validate user
       $validator = Validator::make($request->all(), [
       'password' => 'confirmed',
         ]);

         if ($validator->fails()) {
             return redirect()->back()->withInput()->with('error', 'Can Not add Users');
         }
         $users = User::findOrFail($request->id);

         if($request->password!=''){
           $users->name = $request->name;
           $users->password=Hash::make($request->password);
           $users->save();
           return redirect()->route('edit_profile')->with('success', 'Updated successfully');
         }else{
           $users->name = $request->name;
           $users->save();
           return redirect()->route('edit_profile')->with('success', 'Updated successfully');
         }

    }

    /**
     * User delete
     */
    public function delete($id)
    {
        try {
            User::destroy($id);

            $success = true;
            $message = "User deleted successfully";
        } catch (\Exception $e) {
            $success = false;
            $message = $e->getMessage();
        }

        // return response
        if ($success)
            return redirect()->back()->with('success', $message);
        else
            return redirect()->back()->with('error', $message);
    }
}
