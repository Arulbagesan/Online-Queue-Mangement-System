

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('body_content'); ?>

    <!-- begin:: Subheader -->
    <div class="kt-subheader   kt-grid__item" id="kt_subheader">
        <div class="kt-subheader__main">
            <h3 class="kt-subheader__title">
                <?php echo $__env->yieldContent('title'); ?> </h3>
        </div>
    </div>
    <!-- end:: Subheader -->

    <!-- begin:: Content -->
    <div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">

        <!--Begin::Dashboard 5-->

        <!--Begin::Section-->
        <div class="row">

            <div class="col-xl-6">

                <!--begin:: Recent Clicks-->
                <div class="kt-portlet kt-portlet--tabs kt-portlet--height-fluid">
                    <div class="kt-portlet__head">
                        <div class="kt-portlet__head-label">
                            <h3 class="kt-portlet__head-title">
                                Document List

                            </h3>
                        </div>
                    </div>
                    <div class="kt-portlet__body">
                        <div class="tab-content">
                          <button class="btn btn-success  float-right" style="margin-bottom:15px;" id="createNewBook">Add Document</button>
                            <div class="tab-pane active" id="kt_widget4_tab1_content">

                                <div class="kt-widget4">
                                        <table class="table" id="dataTable">
                                            <thead>
                                            <tr>
                                                <th scope="col">#</th>
                                                <th scope="col">Title</th>
                                                <th scope="col">File </th>
                                                <th scope="col">Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>

                                            </tbody>
                                        </table>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end:: Recent Clicks-->
            </div>

        </div>
        <!--End::Section-->
        
        <div class="modal fade" id="ajaxModel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="modelHeading"></h4>
                    </div>
                    <div class="modal-body">
                        <form id="bookForm" name="bookForm" class="form-horizontal" data-toggle="validator" role="form" enctype="multipart/form-data">
                            <input type="hidden" name="book_id" id="book_id">
                            <div class="form-group">
                                <label for="name" class="col-sm-2 control-label">Title</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Enter title"
                                           value="" maxlength="50" required autocomplete="off">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">File</label>
                                <div class="col-sm-12">
                                    <input type="file" class="form-control" id="author" name="author"
                                           title='Click to add Files'
                                           value="" maxlength="50" required autocomplete="off">
                                </div>
                            </div>
                            <div class="col-sm-offset-2 col-sm-10">
                                <button type="submit" class="btn btn-primary" id="saveBtn">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--End::Dashboard 5-->
    </div>

    <!-- end:: Content -->

    <script type="text/javascript">
        $(function () {
       //ajax setup
       $.ajaxSetup({
           headers: {
               'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
           }
       });

       // datatable
       var table = $('#dataTable').DataTable({
           processing: true,
           serverSide: true,
           ajax: "<?php echo e(url('documents')); ?>",
           columns: [
               {data: 'DT_RowIndex', name: 'DT_RowIndex'},
               {data: 'title', name: 'title'},
               {data: 'file_name', name: 'file_name'},
               {data: 'action', name: 'action', orderable: false, searchable: false},
           ]
       });

       // create new book
       $('#createNewBook').click(function () {
           $('#saveBtn').html("Create");
           $('#book_id').val('');
           $('#bookForm').trigger("reset");
           $('#modelHeading').html("Create New Document");
           $('#ajaxModel').modal('show');
       });

       // create or update book
       $('#saveBtn').click(function (e) {
           e.preventDefault();
           $(this).html('Saving..');
           //notmally ajax not accepting file accept formdata
           var form_data = new FormData(document.getElementById("bookForm"));
           var name = $('#name').val();
           var file = $('input[type="file"]').val();//use this for file
           if(name!='' && file!='' ){
                //validate pdf
                var ext = file.split('.').pop().toLowerCase();
                if($.inArray(ext, ['pdf']) == -1) {
                  var error_messge="Invalid Format. Upload Only Pdf";
                  call_error_notify(error_messge)
                  return false;
                }//validation fail
             $.ajax({
                 data:form_data,
                 url: "<?php echo e(url('documents')); ?>",
                 type: "POST",
                 dataType: 'json',
                 processData: false,
                 contentType: false,
                 cache: false,
                 success: function (data) {
                     $('#bookForm').trigger("reset");
                     $('#ajaxModel').modal('hide');
                     table.draw();
                     $('#saveBtn').html('Save');
                     //call notification function below
                     call_success_notify(data.message)
                 },
                 error: function (data) {
                     console.log('Error:', data);
                     $('#saveBtn').html('Save');
                 }
             });//end of ajax
           }
           else{
              var error_messge="Title Or File Can Not Be Empty";
              call_error_notify(error_messge)
           }//end of else

       });

       // edit book
       $('body').on('click', '.editBook', function () {
           var book_id = $(this).data('id');
           $.get("<?php echo e(url('documents')); ?>" + '/' + book_id + '/edit', function (data) {
               $('#modelHeading').html("Edit Book");
               $('#saveBtn').html('Update');
               $('#ajaxModel').modal('show');
               $('#book_id').val(data.id);
               $('#name').val(data.title);
               //$('#author').val(data.file_name);
           })
       });

       // delete book
       $('body').on('click', '.deleteBook', function () {
           var book_id = $(this).data("id");
           var result = confirm("Are You sure want to delete !");
            if (result) {
                //Logic to delete the item
                $.ajax({
                    type: "DELETE",
                    url: "<?php echo e(url('documents')); ?>" + '/' + book_id,
                    success: function (data) {
                          table.draw();
                          call_success_notify(data.message)
                    },
                    error: function (data) {
                        console.log('Error:', data);
                    }
                });
            }//end of confirm


       });//end of delete function

       //nofification function
       function call_success_notify(mes){
           $.notify({
            // options
            title: 'Notification',
            message: mes,
            },{
            // settings
            type: 'success',
            allow_dismiss: true,
            delay: 2800,
            icon_type: 'class',
            animate: {
                enter: 'animated fadeInDown',
                exit: 'animated fadeOutUp'
            },
            onShow: function() {
                this.css({'width':'auto','height':'auto'});
            },
          });//end of notify
      }//end of call_success_notify

      function call_error_notify(mes){
          $.notify({
           // options
           title: 'Notification',
           message: mes,
           },{
           // settings
           type: 'danger',
           allow_dismiss: true,
           delay: 2800,
           icon_type: 'class',
           animate: {
               enter: 'animated fadeInDown',
               exit: 'animated fadeOutUp'
           },
           onShow: function() {
               this.css({'width':'auto','height':'auto'});
           },
         });//end of notify
     }//end of call_error_notify

   });//end of first if
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.stoken', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\site.test\student-realtime-token\resources\views/admin/document/document_all.blade.php ENDPATH**/ ?>