<?php

use Illuminate\Database\Seeder;

class DocumentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      DB::table('documents')->insert([

        [
            'title' => 'Test File 1',
            'file_name' => 'test1.pdf',
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ],
        [
            'title' => 'Test File 2',
            'file_name' => 'test2.pdf',
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ],
        [
            'title' => 'Test File 3',
            'file_name' => 'test3.pdf',
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ],
        // [
        //     'title' => 'Test File 4',
        //     'file_name' => 'test4.pdf',
        //     'created_at' => date('Y-m-d H:i:s'),
        //     'updated_at' => date('Y-m-d H:i:s'),
        // ],
        // [
        //     'title' => 'Test File 5',
        //     'file_name' => 'test5.pdf',
        //     'created_at' => date('Y-m-d H:i:s'),
        //     'updated_at' => date('Y-m-d H:i:s'),
        // ],
        // [
        //     'title' => 'Test File 6',
        //     'file_name' => 'test6.pdf',
        //     'created_at' => date('Y-m-d H:i:s'),
        //     'updated_at' => date('Y-m-d H:i:s'),
        // ],
        // [
        //     'title' => 'Test File 7',
        //     'file_name' => 'test7.pdf',
        //     'created_at' => date('Y-m-d H:i:s'),
        //     'updated_at' => date('Y-m-d H:i:s'),
        // ],
        // [
        //     'title' => 'Test File 8',
        //     'file_name' => 'test8.pdf',
        //     'created_at' => date('Y-m-d H:i:s'),
        //     'updated_at' => date('Y-m-d H:i:s'),
        // ],
        // [
        //     'title' => 'Test File 9',
        //     'file_name' => 'test9.pdf',
        //     'created_at' => date('Y-m-d H:i:s'),
        //     'updated_at' => date('Y-m-d H:i:s'),
        // ],
        // [
        //     'title' => 'Test File 10',
        //     'file_name' => 'test10.pdf',
        //     'created_at' => date('Y-m-d H:i:s'),
        //     'updated_at' => date('Y-m-d H:i:s'),
        // ],
    ]);
    }
}
