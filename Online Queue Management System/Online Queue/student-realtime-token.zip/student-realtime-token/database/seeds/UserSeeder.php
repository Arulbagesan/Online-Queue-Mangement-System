<?php

use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            [
                'name' => 'Admin 1',
                'student_id' => '',
                'email' => 'admin@test.com',
                'password' => bcrypt('123456'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
                'role' => 'admin',
            ],
            [
                'name' => 'Staff 1',
                'student_id' => '',
                'email' => 'staff1@test.com',
                'password' => bcrypt('123456'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
                'role' => 'staff',
            ],
            [
                'name' => 'Staff 2',
                'student_id' => '',
                'email' => 'staff2@test.com',
                'password' => bcrypt('123456'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
                'role' => 'staff',
            ],
            [
                'name' => 'Student 1',
                'student_id' => '123-15-01',
                'email' => 'student1@test.com',
                'password' => bcrypt('123456'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
                'role' => 'student',
            ],
            [
                'name' => 'Student 2',
                'student_id' => '123-15-02',
                'email' => 'student2@test.com',
                'password' => bcrypt('123456'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
                'role' => 'student',
            ],
            [
                'name' => 'Student 3',
                'student_id' => '123-15-03',
                'email' => 'student3@test.com',
                'password' => bcrypt('123456'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
                'role' => 'student',
            ],
            [
                'name' => 'Student 4',
                'student_id' => '123-15-04',
                'email' => 'student4@test.com',
                'password' => bcrypt('123456'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
                'role' => 'student',
            ],
            [
                'name' => 'Student 5',
                'student_id' => '123-15-05',
                'email' => 'student5@test.com',
                'password' => bcrypt('123456'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
                'role' => 'student',
            ],
        ]);
    }
}
