<?php

use Illuminate\Support\Facades\Route;

Auth::routes();

Route::group(['middleware' => ['auth']], function () {
    Route::get('/', 'HomeController@index')->name('home');

    //users
    Route::prefix('users')->group(function () {
        Route::get('/', 'UserController@list')->name('list');
        Route::get('add', 'UserController@add');
        Route::post('store', 'UserController@store')->name('user_store');
        Route::get('edit/{id}', 'UserController@edit');
        Route::post('update', 'UserController@update')->name('user_update');
        Route::get('delete/{id}', 'UserController@delete');
        Route::get('profile', 'UserController@edit_profile')->name('edit_profile');
        Route::post('update_profile', 'UserController@update_profile')->name('update_profile');
    });

    //admin functions
     Route::resource('documents','DocumentController');

    //report
    Route::get('/report', 'ReportController@index')->name('report');
    Route::post('/get_report', 'ReportController@store')->name('get_report');

    //staff functions
     Route::get('/token_list', 'TokenController@index')->name('token_list');
     Route::post('/next_token', 'TokenController@nextToken')->name('next_token');
});
