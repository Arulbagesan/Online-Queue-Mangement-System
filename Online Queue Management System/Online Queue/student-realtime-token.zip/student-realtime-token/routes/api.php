<?php

use Illuminate\Support\Facades\Route;

// user
Route::prefix('user')->group(function () {
    Route::post('login', 'API\UserController@login');
});

// firebase
Route::prefix('firebase')->group(function () {
    Route::post('appoint', 'API\FirebaseController@appoint');
    Route::post('cancel_appoint', 'API\FirebaseController@cancelAppoint');
});

// document
Route::prefix('document')->group(function () {
    Route::get('list', 'API\DocumentController@list');
});
