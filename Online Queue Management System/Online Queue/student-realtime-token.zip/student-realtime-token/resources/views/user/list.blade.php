@extends('layouts.stoken')

@section('title', 'Manage Users')

@section('body_content')

<!-- begin:: Content -->
<div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content" style="margin-top: 30px;">
    <div class="kt-portlet kt-portlet--mobile">
        <div class="kt-portlet__head kt-portlet__head--lg">
            <div class="kt-portlet__head-label">
                <h3 class="kt-portlet__head-title">
                    @yield('title')
                </h3>
            </div>
            <div class="kt-portlet__head-toolbar">
                <div class="kt-portlet__head-wrapper">
                    <div class="dropdown dropdown-inline">

                        <a href="{{url('users/add')}}" class="" title="Add User">
                            <button id="addCategory" class="btn btn-brand btn-icon-sm">
                                <i class="flaticon2-plus"></i>
                                Add New
                            </button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="kt-portlet__body">

          @if (session('success'))
            <script>
              //report notification
              $(document).ready(function(){
                $.notify({
                 // options
                 title: 'Notification',
                 message: 'User Updated Successfully',
                 },{
                 // settings
                 type: 'success',
                 allow_dismiss: true,
                 delay: 2800,
                 icon_type: 'class',
                 animate: {
                     enter: 'animated fadeInDown',
                     exit: 'animated fadeOutUp'
                 },
                 onShow: function() {
                     this.css({'width':'auto','height':'auto'});
                 },
               });//end of notify
              });
            </script>
          @endif
          @if (session('error'))
            <script>
              //report notification
              $(document).ready(function(){
                $.notify({
                 // options
                 title: 'Notification',
                 message: 'Can Not Update User',
                 },{
                 // settings
                 type: 'danger',
                 allow_dismiss: true,
                 delay: 2800,
                 icon_type: 'class',
                 animate: {
                     enter: 'animated fadeInDown',
                     exit: 'animated fadeOutUp'
                 },
                 onShow: function() {
                     this.css({'width':'auto','height':'auto'});
                 },
               });//end of notify
              });
            </script>
          @endif

            {{--display data--}}
            @if (count($users) > 0)
                <section class="users">
                    @include('user.ajax_loader')
                </section>
            @else
                No data found :(
            @endif

        </div>
    </div>
</div>
<!-- end:: Content -->

{{--ajax pagination--}}
<script>
    $(function () {
        $('body').on('click', '.pagination a', function (e) {
            e.preventDefault();
            $('#ajaxTable').append('<img class="ajaxTableLoader" src="{{url('backend/loading.gif')}}" />');
            var url = $(this).attr('href');
            window.history.pushState("", "", url);
            loadData(url);
        });

        function loadData(url) {
            $("#ajaxTable").addClass("onLoading");
            $.ajax({
                url: url
            }).done(function (data) {
                $('.users').html(data);
                $("#ajaxTable").removeClass("onLoading");
            }).fail(function () {
                console.log("Failed to load data!");
                $("#ajaxTable").removeClass("onLoading");
            });
        }
    });
</script>

{{--delete--}}
<script>
    $(document).on('click', '#deleteUser', function () {
        var id = $(this).data('info');

        swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            type: "warning",
            buttonsStyling: !1,
            showCancelButton: !0,
            confirmButtonText: "Yes, delete it!",
            confirmButtonClass: "btn btn-danger",
            cancelButtonText: "No, cancel!",
            cancelButtonClass: "btn btn-default",
            reverseButtons: !0
        }).then(function (e) {
            e.value ? location.href = "{{ url('/users/delete') }}" + "/" + id : "cancel" === e.dismiss
        }, function (dismiss) {
            return false;
        })

    });
</script>

@endsection
