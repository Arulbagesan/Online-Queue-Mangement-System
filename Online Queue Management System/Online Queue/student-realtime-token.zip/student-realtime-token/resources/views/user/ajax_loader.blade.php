<div id="ajaxTable">
    <table class="table table-bordered">
        <thead class="thead-light">
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Actions</th>
        </tr>
        </thead>
        <tbody>
        @foreach($users as $user)
            <tr>
                <td class="id">{{ $user->id}}</td>
                <td>{{ $user->name }}</td>
                <td>{{ $user->email }}</td>
                <td class="action_category">
                    <a id="editCategory" href="{{url('users/edit') . '/' . $user->id}}"
                       class="btn btn-sm btn-clean btn-icon btn-icon-sm"
                       title="Edit"><i class="flaticon-edit-1"></i></a>
                    <a id="deleteUser" data-info="{{$user->id}}"
                       class="btn btn-sm btn-clean btn-icon btn-icon-sm"
                       title="Delete"><i class="flaticon2-trash"></i></a>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>

{!! $users->render() !!}
