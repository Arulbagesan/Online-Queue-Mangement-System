@extends('layouts.stoken')

@section('title', 'Dashboard')

@section('body_content')

    <!-- begin:: Subheader -->
    <div class="kt-subheader   kt-grid__item" id="kt_subheader">
        <div class="kt-subheader__main">
            <h3 class="kt-subheader__title">
              Edit User </h3>
        </div>
    </div>
    <!-- end:: Subheader -->

    <!-- begin:: Content -->
    <div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">

        <!--Begin::Dashboard 5-->

        <!--Begin::Section-->
        <div class="row">

            <div class="col-xl-6">

                <!--begin:: Recent Clicks-->
                <div class="kt-portlet kt-portlet--tabs kt-portlet--height-fluid">
                    <div class="kt-portlet__head">
                        <div class="kt-portlet__head-label">
                            <h3 class="kt-portlet__head-title">
                                <a href="{{url()->previous()}}"><i class="fa fa-arrow-left" aria-hidden="true"></i>&nbsp;Back</a> 
                            </h3>
                        </div>
                    </div>
                    <div class="kt-portlet__body">
                        <div class="tab-content">
                            <div class="tab-pane active" id="kt_widget4_tab1_content">
                                <div class="kt-widget4">
                                  @if (session('success'))
                                    <script>
                                      //report notification
                                      $(document).ready(function(){
                                        $.notify({
                                         // options
                                         title: 'Notification',
                                         message: 'User Added Successfully',
                                         },{
                                         // settings
                                         type: 'success',
                                         allow_dismiss: true,
                                         delay: 2800,
                                         icon_type: 'class',
                                         animate: {
                                             enter: 'animated fadeInDown',
                                             exit: 'animated fadeOutUp'
                                         },
                                         onShow: function() {
                                             this.css({'width':'auto','height':'auto'});
                                         },
                                       });//end of notify
                                      });
                                    </script>
                                  @endif
                                  @if (session('error'))
                                    <script>
                                      //report notification
                                      $(document).ready(function(){
                                        $.notify({
                                         // options
                                         title: 'Notification',
                                         message: 'Email Exists.Use Another Email',
                                         },{
                                         // settings
                                         type: 'danger',
                                         allow_dismiss: true,
                                         delay: 2800,
                                         icon_type: 'class',
                                         animate: {
                                             enter: 'animated fadeInDown',
                                             exit: 'animated fadeOutUp'
                                         },
                                         onShow: function() {
                                             this.css({'width':'auto','height':'auto'});
                                         },
                                       });//end of notify
                                      });
                                    </script>
                                  @endif
                                  <form  class="form-horizontal" method="POST" action="{{ route('user_update') }}" >
                                        @csrf
                                        <input type="hidden" name="id" value="{{$users->id}}">
                                      <div class="form-group">
                                          <label for="name" class="col-sm-2 control-label">Name</label>
                                          <div class="col-sm-12">
                                              <input type="text" class="form-control" value="{{$users->name}}" style="width:50%"  name="name"
                                                      maxlength="50" required autocomplete="off">
                                          </div>
                                      </div>
                                      <div class="form-group">
                                          <label for="name" class="col-sm-2 control-label">Email</label>
                                          <div class="col-sm-12">
                                              <input type="email" class="form-control" value="{{$users->email}}" style="width:50%"  name="email"
                                                      maxlength="50" required autocomplete="off" readonly>
                                          </div>
                                      </div>

                                      <div class="form-group">
                                          <label for="name" class="col-sm-2 control-label" >Role</label>
                                          <div class="col-sm-12">
                                              <select class="form-control"  name="role" style="width:50%" required>
                                                <option  selected value="{{$users->role}}" >
                                                  @if($users->role=='student')
                                                   Student
                                                  @endif
                                                  @if($users->role=='admin')
                                                   Admin
                                                  @endif
                                                  @if($users->role=='staff')
                                                   Staff
                                                  @endif
                                                </option>
                                                <option value="student">Student</option>
                                                <option value="staff">Saff</option>
                                                <option value="admin">Admin</option>
                                              </select>
                                          </div>
                                      </div>
                                      <div class="col-sm-offset-2 col-sm-10">
                                          <button type="submit" class="btn btn-primary" >Submit</button>
                                      </div>
                                  </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end:: Recent Clicks-->
            </div>

        </div>
        <!--End::Section-->

        <!--End::Dashboard 5-->
    </div>

    <!-- end:: Content -->

@endsection
