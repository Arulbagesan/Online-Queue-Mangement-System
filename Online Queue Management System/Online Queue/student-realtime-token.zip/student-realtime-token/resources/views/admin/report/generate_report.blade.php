@extends('layouts.stoken')

@section('title', 'Dashboard')

@section('body_content')

    <!-- begin:: Subheader -->
    <div class="kt-subheader   kt-grid__item" id="kt_subheader">
        <div class="kt-subheader__main">
            <h3 class="kt-subheader__title">
                @yield('title') </h3>
        </div>
    </div>
    <!-- end:: Subheader -->

    <!-- begin:: Content -->
    <div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">

        <!--Begin::Dashboard 5-->

        <!--Begin::Section-->
        <div class="row">

            <div class="col-xl-6">

                <!--begin:: Recent Clicks-->
                <div class="kt-portlet kt-portlet--tabs kt-portlet--height-fluid">
                    <div class="kt-portlet__head">
                        <div class="kt-portlet__head-label">
                            <h3 class="kt-portlet__head-title">
                                Report
                            </h3>
                        </div>
                    </div>
                    <div class="kt-portlet__body">
                        <div class="tab-content">
                            <div class="tab-pane active" id="kt_widget4_tab1_content">
                                <div class="kt-widget4">
                                        @if (session('success'))
                                          <script>
                                            //report notification
                                            $(document).ready(function(){
                                                $.notify("Report Generated successfully");
                                            });
                                          </script>
                                        @endif
                                        <form  class="form-horizontal" method="POST" action="{{ route('get_report') }}" >
                                              @csrf
                                            <div class="form-group">
                                                <label for="name" class="col-sm-2 control-label">Select Date</label>
                                                <div class="col-sm-12">
                                                    <input type="text" class="form-control" style="width:30%" id="cal" name="get_date"
                                                            maxlength="50" required autocomplete="off">
                                                </div>
                                            </div>
                                            <div class="col-sm-offset-2 col-sm-10">
                                                <button type="submit" class="btn btn-primary" id="saveBtn">Generate</button>
                                            </div>
                                        </form>
                                        <!-- table here -->
                                        <table class="table table-bordered" style="margin-top:40px;">
                                            <thead class="thead-light">
                                            <tr>
                                                <th scope="col">Date</th>
                                                <th scope="col">File Name</th>
                                                <th scope="col">Actions</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                                @foreach($reports as $report)
                                                <tr>
                                                    <td class="id">{{$report->created_at}}</td>
                                                    <td>{{$report->report_name}}</td>
                                                    <td class="action_category">
                                                        <a id="editCategory" href="reports/{{$report->report_name}}" target="_blank"
                                                           class="btn btn-sm btn-clean btn-icon btn-icon-sm"
                                                           title="View"><i class="fa fa-download"></i></a>

                                                    </td>
                                                </tr>
                                              @endforeach
                                            </tbody>

                                        </table>
                                        {!! $reports->render() !!}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end:: Recent Clicks-->
            </div>

        </div>
        <!--End::Section-->

        <!--End::Dashboard 5-->
    </div>

    <!-- end:: Content -->
    <script type="text/javascript">

        $('#cal').datepicker({

           format: 'yyyy-mm-dd'

         });

    </script>
@endsection
