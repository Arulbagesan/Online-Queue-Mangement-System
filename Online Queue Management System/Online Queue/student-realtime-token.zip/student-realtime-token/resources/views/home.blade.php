@extends('layouts.stoken')

@section('title', 'Dashboard')

@section('body_content')

    <!-- begin:: Subheader -->
    <div class="kt-subheader   kt-grid__item" id="kt_subheader">
        <div class="kt-subheader__main">
            <h3 class="kt-subheader__title">
                @yield('title') </h3>
        </div>
    </div>
    <!-- end:: Subheader -->

    <!-- begin:: Content -->
    <?php
      $total_user=DB::table('users')->where('role', 'student')->count();
      $total_staff=DB::table('users')->where('role', 'staff')->count();
      $total_student_served=DB::table('archives')->count();
    ?>
    <div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">

        <div class="row">
          @if(Auth::user()->role=='admin')
            <div class="col-sm-4">
              <div class="card border-info mx-sm-1 p-3">
                 <div class="card border-info shadow text-info p-3 my-card" ><span class="fa fa-user" aria-hidden="true"></span></div>
                 <div class="text-info text-center mt-3"><h4>Users</h4></div>
                 <div class="text-info text-center mt-2"><h1>{{$total_user}}</h1></div>
             </div>
            </div>
            <div class="col-sm-4">
              <div class="card border-success mx-sm-1 p-3">
                <div class="card border-success shadow text-success p-3 my-card"><span class="fa fa-users" aria-hidden="true"></span></div>
                <div class="text-success text-center mt-3"><h4>Staff</h4></div>
                <div class="text-success text-center mt-2"><h1>{{$total_staff}}</h1></div>
              </div>
            </div>
            <div class="col-sm-4">
              <div class="card border-danger mx-sm-1 p-3">
                <div class="card border-danger shadow text-danger p-3 my-card" ><span class="fa fa-heart" aria-hidden="true"></span></div>
                <div class="text-danger text-center mt-3"><h4>Total Served</h4></div>
                <div class="text-danger text-center mt-2"><h1>{{$total_student_served}}</h1></div>
             </div>
            </div>
            @endif
            @if(Auth::user()->role=='staff')
            <div class="col-sm-4">
              <div class="card border-danger mx-sm-1 p-3">
                <div class="card border-danger shadow text-danger p-3 my-card" ><span class="fa fa-heart" aria-hidden="true"></span></div>
                <div class="text-danger text-center mt-3"><h4>Total Served</h4></div>
                <div class="text-danger text-center mt-2"><h1>{{$total_student_served}}</h1></div>
             </div>
            </div>
              @endif
        </div><!-- end of row -->
    </div><!-- end of kt-content -->

@endsection
