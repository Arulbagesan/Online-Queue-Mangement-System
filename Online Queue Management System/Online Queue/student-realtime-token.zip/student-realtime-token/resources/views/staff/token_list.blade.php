@extends('layouts.stoken')

@section('title', 'Dashboard')

@section('body_content')

    <!-- begin:: Subheader -->
    <div class="kt-subheader   kt-grid__item" id="kt_subheader">
        <div class="kt-subheader__main">
            <h3 class="kt-subheader__title">
                @yield('title') </h3>
        </div>
    </div>
    <!-- end:: Subheader -->

    <!-- begin:: Content -->
    <div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">

        <div class="row">
            <div class="col-sm-4">
                <div class="card">
                    <div class="card-body">
                        <center>
                            <h5 class="card-title">Current Token </h5>
                            <button type="button" class="btn btn-warning">
                                <!-- <h1 id="tbody"><span></span></h1> -->
                                <h1>
                                    @if ($in_service !=  null)
                                        <p id="token">{{ $in_service->token}}</p>
                                    @else
                                        ---
                                    @endif
                                </h1>
                            </button>
                            <br><br><br>
                        </center>
                        @if($in_queue > 0)
                            @if($next !=  null)
                                <form method="POST" action="{{ route('next_token') }}" enctype="multipart/form-data">
                                    @csrf
                                    <input type="hidden" id="counter_no" name="counter_no" value="{{$counter_no}}"/>
                                    <input type="hidden" id="firebase_key" name="firebase_key" value="{{$in_service->firebase_key}}"/>
                                    <button type="submit" style="float:right;" class="btn btn-sm btn-success">Call Next <i
                                            class="fa fa-arrow-right" aria-hidden="true"></i></button>
                                </form>
                           @else
                                <form method="POST" action="{{ route('next_token') }}" enctype="multipart/form-data">
                                    @csrf
                                    <input type="hidden" id="counter_no" name="counter_no" value="{{$counter_no}}"/>
                                    <input type="hidden" id="firebase_key" name="firebase_key" value="{{$in_service->firebase_key}}"/>
                                    <button type="submit" style="float:right;" class="btn btn-sm btn-success">Finish <i
                                            class="fa fa-arrow-right" aria-hidden="true"></i></button>
                                </form>
                            @endif
                        @endif
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">List</h5>
                        <table class="table table-bordered">
                            <thead class="thead-light">
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Token Number</th>
                                <th scope="col">Student Name</th>
                                <th scope="col">Student ID</th>
                                <th scope="col">counter</th>
                                <!-- <th scope="col">Recall</th> -->
                            </tr>
                            </thead>
                            <tbody id="tabledata">
                            @if($tokens != null)
                                @foreach($tokens as $token)
                                    <tr>
                                        <td class="id">{{ $token->id}}</td>
                                        <td>{{ $token->token}}</td>
                                        <td>{{ $token->user->name}}</td>
                                        <td>{{ $token->user->student_id}}</td>
                                        <td>{{ $token->counter}}</td>
                                        <!-- <td class="action_category">
                                            <button
                                                class="btn btn-sm btn-clean btn-icon btn-icon-sm"
                                                title="Recall"><i class="fa fa-redo" aria-hidden="true"></i></button>
                                        </td> -->
                                    </tr>
                                @endforeach
                            @endif
                            </tbody>
                        </table>
                        @if($in_queue <=0 )
                            <div>
                                <p style="text-align: center;">No data</p>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div><!-- end of row -->
    </div><!-- end of kt-content -->

@endsection
