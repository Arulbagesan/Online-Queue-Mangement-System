package com.stoken.stoken.api;

public class Constants {
    public static final String SERVER = "http://192.168.43.40/student-realtime-token/public";
    public static final String ANDROID_BASE_URL = SERVER + "/api/";
}