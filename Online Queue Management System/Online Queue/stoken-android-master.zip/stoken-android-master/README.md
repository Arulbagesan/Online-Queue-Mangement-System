## SToken Android
Realtime Token Management Android Application

### Output
![stoekn-app](https://user-images.githubusercontent.com/13184472/80479919-9b6ad100-8971-11ea-8cae-c1b93ae8ba27.gif)
